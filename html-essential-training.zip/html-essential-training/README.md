# HTML Essential Training

A Pen created on CodePen.io. Original URL: [https://codepen.io/ml3147/pen/ZErNKWo](https://codepen.io/ml3147/pen/ZErNKWo).

