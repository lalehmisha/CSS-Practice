# CSS Essential Training 1

A Pen created on CodePen.io. Original URL: [https://codepen.io/ml3147/pen/ZErNPGZ](https://codepen.io/ml3147/pen/ZErNPGZ).

