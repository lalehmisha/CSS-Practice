/**
 * Practice: Building objects
 *
 * - Create JavaScript objects based on objects in your current environment.
 * - Give each object an identifiable name.
 * - Create properties to describe the objects and set their values.
 * - Find an object that has another object inside of it to create a nested object.
 * - Test your objects in the browser console by accessing the entire object and its specific properties.
 */

const mehraan = {
    title: "Mehraan",
    nose: "roman",
    hair: "curly",
    pants: "black", 
    socks: "grey"
};

document.getElementById("object title").innerHTML = mehraan.title
document.getElementById("first object").innerHTML = mehraan.hair
document.getElementById("second object").innerHTML = mehraan.nose
document.getElementById("third object").innerHTML = mehraan.pants
document.getElementById("fourth object").innerHTML = mehraan.socks