/**
 * Create a Backpack object, populate some HTML to display its properties.
 */
/********STAART MY CODE******** */
function Change_BackpackColor(dropdown_id) {
  let myDropdown = document.getElementById(dropdown_id);

  backpack.picture = `backpack_images/${myDropdown.value}_backpack.jpg`;

  /******We were able to rewrite all this code
   * in a more efficient way as above!!! */

  // if (myDropdown.value == "green") {
  //   backpack.picture = "backpack_images/green_backpack.jpg";
  // }
  // if (myDropdown.value == "yellow") {
  //   backpack.picture = "backpack_images/yellow_backpack.jpg";
  // }
  // if (myDropdown.value == "blue") {
  //   backpack.picture = "backpack_images/blue_backpack.jpg";
  // }

  updateBackpack();
}
/********END MY CODE******** */

const updateBackpack = (update) => {
  let main = document.querySelector("main");
  main.innerHTML = markup(backpack);
  console.info(update);
};

const backpack = {
  name: "Everyday Backpack",
  volume: 30,
  color: "green",
  picture: "backpack_images/green_backpack.jpg",
  pocketNum: 15,
  strapLength: {
    left: 26,
    right: 26,
  },
  lidOpen: false,
  toggleLid: function (lidStatus) {
    this.lidOpen = lidStatus;
    updateBackpack(`Lid status changed.`);
  },
  newStrapLength: function (lengthLeft, lengthRight) {
    this.strapLength.left = lengthLeft;
    this.strapLength.right = lengthRight;
    updateBackpack(`Strap lengths updated.`);
  },
};

const markup = (backpack) => {
  return `
  <div>
    <h3>${backpack.name}</h3>
    <ul>
      <li>Volume: ${backpack.volume}</li>
      <li>Color: ${backpack.color}</li>
      <li>Number of pockets: ${backpack.pocketNum}</li>
      <li>Strap lengths: L: ${backpack.strapLength.left}, R: ${
    backpack.strapLength.right
  } </li>
      <li>Top lid: ${backpack.lidOpen ? "Open" : "Closed"}</li>
      <li><img style="width: 200px; height: 200px" src=${backpack.picture}></li>
    </ul>
  </div>
`;
};

const main = document.createElement("main");
main.innerHTML = markup(backpack);
document.body.appendChild(main);
